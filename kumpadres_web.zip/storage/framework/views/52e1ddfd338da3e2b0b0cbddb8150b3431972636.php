<transaction-detail-listing
:data="<?php echo e($data->toJson()); ?>"
:url="'<?php echo e(url('app/transaction-details').'/list' . '/'. $transactionHeader->id); ?>'"
inline-template>

<div class="row">
    <div class="col">
        <div class="card">
            <div class="card-header">
                <i class="fa fa-align-justify"></i> <?php echo e(trans('admin.transaction-detail.actions.index')); ?>


                <a v-show="<?php echo e($transactionHeader->status); ?> == 0 | isReadOnly == 1" class="btn btn-primary btn-spinner btn-sm pull-right m-b-0" href="<?php echo e(url('app/transaction-details/create')); ?>?txnId=<?php echo e($transactionHeader->id); ?>" role="button"><i class="fa fa-plus"></i>&nbsp; <?php echo e(trans('admin.transaction-detail.actions.create')); ?></a>
            </div>
            <div class="card-body" v-cloak>
                <div class="card-block">

                    <table class="table table-hover table-listing">
                        <thead>
                            <tr>

                                <th is='sortable' :column="'item_id'"><?php echo e(trans('admin.transaction-detail.columns.item_id')); ?></th>
                                <th is='sortable' :column="'quantity'"><?php echo e(trans('admin.transaction-detail.columns.quantity')); ?></th>
                                <th is='sortable' :column="'amount'"><?php echo e(trans('admin.transaction-detail.columns.amount')); ?></th>

                                <th></th>
                            </tr>

                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in collection" :key="item.id" :class="bulkItems[item.id] ? 'bg-bulk' : ''">


                                <td>{{ item.item.brand.name +  " - " + item.item.name }}</td>
                                <td>{{ item.quantity }}</td>
                                <td>{{ item.amount }}</td>
                                <td>
                                    <div class="row no-gutters">
                                        <form class="col" @submit.prevent="deleteItem(item.resource_url)">
                                            <button type="submit" v-show="<?php echo e($transactionHeader->status); ?> == 0 && isReadOnly" class="btn btn-sm btn-danger" title="<?php echo e(trans('brackets/admin-ui::admin.btn.delete')); ?>"><i class="fa fa-trash-o"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="row" v-if="pagination.state.total > 0">
                        <div class="col-sm">
                            <span class="pagination-caption"><?php echo e(trans('brackets/admin-ui::admin.pagination.overview')); ?></span>
                        </div>
                        <div class="col-sm-auto">
                            <pagination></pagination>
                        </div>
                    </div>

                    <div class="no-items-found" v-if="!collection.length > 0">
                        <i class="icon-magnifier"></i>
                        <h3><?php echo e(trans('brackets/admin-ui::admin.index.no_items')); ?></h3>
                        <p><?php echo e(trans('brackets/admin-ui::admin.index.try_changing_items')); ?></p>
                        <a class="btn btn-primary btn-spinner" href="<?php echo e(url('app/transaction-details/create')); ?>?txnId=<?php echo e($transactionHeader->id); ?>" role="button"><i class="fa fa-plus"></i>&nbsp; <?php echo e(trans('admin.transaction-detail.actions.create')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</transaction-detail-listing>
<?php /**PATH D:\xampp\htdocs\kumpadres_web\resources\views/admin/transaction-header/components/transaction-detail.blade.php ENDPATH**/ ?>