
<?php /**PATH D:\xampp\htdocs\kumpadres_web\vendor\brackets\admin-ui\src/../resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>