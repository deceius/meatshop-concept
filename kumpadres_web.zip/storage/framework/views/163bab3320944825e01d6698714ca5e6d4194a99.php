<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
           
           
           <?php if(in_array(app('user_tier_id'), app('employee_access'))): ?>
            <li class="nav-title">Reports</li>

            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/transaction-details')); ?>"><i class="nav-icon icon-layers"></i> Inventory Details</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/transaction-details')); ?>"><i class="nav-icon icon-chart"></i> Sales Report</a></li>

            <li class="nav-title">Transactions</li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/transaction-headers').'/1'); ?>"><i class="nav-icon icon-note"></i> <?php echo e(trans('admin.receiving.title')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/transaction-headers').'/2'); ?>"><i class="nav-icon icon-basket"></i> <?php echo e(trans('admin.sales.title')); ?></a></li>
            <?php endif; ?>
            <?php if(in_array(app('user_tier_id'), app('manager_access'))): ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/transfers')); ?>"><i class="nav-icon icon-share-alt"></i> Transfer Module </a></li>

            <li class="nav-title">Price Maintenance</li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/prices')); ?>"><i class="nav-icon icon-tag"></i> <?php echo e(trans('admin.price.title')); ?></a></li>

            <li class="nav-title">Customer Management</li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/customers')); ?>"><i class="nav-icon icon-people"></i> Customers </a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/traders')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(trans('admin.trader.title')); ?></a></li>

            <li class="nav-title">Expense Management</li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/expenses')); ?>"><i class="nav-icon icon-wallet"></i> <?php echo e(trans('admin.expense.title')); ?></a></li>
            <?php endif; ?>
            <?php if(in_array(app('user_tier_id'), app('admin_access'))): ?>

            <li class="nav-title"><?php echo e(trans('admin.terms.item_master_data')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/items')); ?>"><i class="nav-icon icon-docs"></i> <?php echo e(trans('admin.item.title')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/types')); ?>"><i class="nav-icon icon-docs"></i> <?php echo e(trans('admin.type.title')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/brands')); ?>"><i class="nav-icon icon-docs"></i> <?php echo e(trans('admin.brand.title')); ?></a></li>
            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.settings')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/access-tiers')); ?>"><i class="nav-icon icon-lock"></i> <?php echo e(trans('admin.access-tier.title')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/branches')); ?>"><i class="nav-icon icon-location-pin"></i> <?php echo e(trans('admin.branch.title')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('app/admin-users')); ?>"><i class="nav-icon icon-user-following"></i> <?php echo e(__('User Management')); ?></a></li>
            <?php endif; ?>
           
            
            
            
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH D:\xampp\htdocs\kumpadres_web\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>