<div class="form-group row align-items-center" :class="{'has-danger': errors.has('ref_no'), 'has-success': fields.ref_no && fields.ref_no.valid }">
    <div class="col-lg-12">
        <div id="reader" width="600px"></div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\kumpadres_web\resources\views/admin/transaction-detail/components/qrscanner.blade.php ENDPATH**/ ?>