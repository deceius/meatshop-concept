<?php $__env->startSection('title', trans('admin.transaction-detail.actions.create')); ?>
<?php $__env->startSection('body'); ?>
<transaction-detail-form
:action="'<?php echo e(url('app/transaction-details')); ?>'"
:transaction-header-id="<?php echo e($transactionHeaderId); ?>"
:transaction-type=<?php echo e($transactionType); ?>

:item="<?php echo e($item); ?>"
v-cloak
inline-template>

    <div class="container-xl">

                <div class="card">
            <form class="form-horizontal form-create" method="post" @submit.prevent="onSubmit" :action="action" novalidate>

                <div class="card-header">
                    <i class="fa fa-plus"></i> <?php echo e(trans('admin.transaction-detail.actions.create')); ?>

                    <a class="btn btn-primary btn-spinner btn-sm pull-right m-b-0" href="<?php echo e(url('app/transaction-headers/'.$transactionHeaderId.'/edit')); ?>" role="button"><i class="fa fa-edit"></i>&nbsp; Return to Transaction</a>

                </div>

                <div class="card-body">

                    <?php echo $__env->make('admin.transaction-detail.components.qrscanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php switch($transactionType):
                        case (1): ?>
                            <?php echo $__env->make('admin.transaction-detail.components.receiving-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php break; ?>
                        <?php case (2): ?>
                            <?php echo $__env->make('admin.transaction-detail.components.sales-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php break; ?>
                        <?php case (3): ?>
                            <?php echo $__env->make('admin.transaction-detail.components.pullout-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php break; ?>
                        <?php case (4): ?>
                            <?php echo $__env->make('admin.transaction-detail.components.delivery-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php break; ?>
                        <?php default: ?>

                    <?php endswitch; ?>
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary" :disabled="submiting">
                        <i class="fa" :class="submiting ? 'fa-spinner' : 'fa-download'"></i>
                        <?php echo e(trans('brackets/admin-ui::admin.btn.save')); ?>

                    </button>
                </div>

            </form>


        </div>

        </div>


    </transaction-detail-form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\kumpadres-web\resources\views/admin/transaction-detail/create.blade.php ENDPATH**/ ?>