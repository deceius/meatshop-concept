<a href="<?php echo e(url('app')); ?>" class="navbar-brand">
    
    

    
    Kumpadres
</a>
<?php /**PATH D:\Projects\kumpadres-web\resources\views/admin/layout/logo.blade.php ENDPATH**/ ?>