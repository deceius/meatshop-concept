<?php $__env->startSection('title', trans('admin.'.$transactionType.'.actions.edit', ['name' => $transactionHeader->ref_no])); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-xl">
        <div class="card">
            <transaction-header-form
            :action="'<?php echo e($transactionHeader->resource_url); ?>'"
            :data="<?php echo e($transactionHeader->toJson()); ?>"
            :delivery_branch="<?php echo e(($deliveryBranch) ? $deliveryBranch->toJson() : null); ?>"
            :current-branch = "<?php echo e($transactionHeader->branch->toJson()); ?>"
            :is-read-only = "<?php echo e($isReadOnly); ?>"
            v-cloak
            inline-template>

                <form class="form-horizontal form-edit" method="post" @submit.prevent="onSubmit" :action="action" novalidate>

                    <div class="card-header">
                        <i class="fa fa-pencil"></i> <?php echo e(trans('admin.'.$transactionType.'.actions.edit', ['name' => $transactionHeader->ref_no])); ?>


                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('admin.transaction-header.components.'.$transactionType.'-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>


                    <div class="card-footer">
                        <button v-show="<?php echo e($transactionHeader->status); ?> == 0 && isReadOnly == 0" type="submit" class="btn btn-primary" :disabled="submiting">
                            <i class="fa" :class="submiting ? 'fa-spinner' : 'fa-download'"></i>
                            Update
                        </button>
                            <button v-show="<?php echo e($transactionHeader->status); ?> == 0 && isReadOnly == 0" type="button" class="btn btn-danger" :disabled="submiting" @click="finalize(data.resource_url)">
                                <i class="fa" :class="submiting ? 'fa-spinner' : 'fa-edit'"></i>
                                Finalize
                        </button>

                    </div>

                </form>
            </transaction-header-form>


        </div>


        <?php echo $__env->make('admin.transaction-header.components.transaction-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kumpadres_web\resources\views/admin/transaction-header/edit.blade.php ENDPATH**/ ?>