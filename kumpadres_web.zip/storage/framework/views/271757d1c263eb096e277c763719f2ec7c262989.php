import AppListing from '../app-components/Listing/AppListing';

Vue.component('<?php echo e($modelJSName); ?>-listing', {
    mixins: [AppListing]
});<?php /**PATH D:\Projects\kumpadres-web\vendor\brackets\admin-generator\src/../resources/views/listing-js.blade.php ENDPATH**/ ?>