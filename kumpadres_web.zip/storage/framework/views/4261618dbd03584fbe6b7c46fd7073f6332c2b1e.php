<a href="<?php echo e(url('app')); ?>" class="navbar-brand">
    
    

    
    Kumpadres [Test Environment]
</a>
<?php /**PATH D:\xampp\htdocs\kumpadres_web\resources\views/admin/layout/logo.blade.php ENDPATH**/ ?>