<?php $__env->startSection('body'); ?>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('brackets/admin-ui::admin.layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\kumpadres-web\vendor\brackets\admin-auth\src/../resources/views/admin/homepage/index.blade.php ENDPATH**/ ?>