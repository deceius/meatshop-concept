import AppListing from '../app-components/Listing/AppListing';

Vue.component('access-tier-listing', {
    mixins: [AppListing]
});