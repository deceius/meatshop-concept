import AppListing from '../app-components/Listing/AppListing';

Vue.component('branch-listing', {
    mixins: [AppListing]
});