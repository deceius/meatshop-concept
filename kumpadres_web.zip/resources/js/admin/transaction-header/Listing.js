import AppListing from '../app-components/Listing/AppListing';

Vue.component('transaction-header-listing', {
    mixins: [AppListing]
});