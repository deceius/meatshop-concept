import AppListing from '../app-components/Listing/AppListing';

Vue.component('customer-listing', {
    mixins: [AppListing]
});