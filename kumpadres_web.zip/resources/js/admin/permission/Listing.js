import AppListing from '../app-components/Listing/AppListing';

Vue.component('permission-listing', {
    mixins: [AppListing]
});