import AppListing from '../app-components/Listing/AppListing';

Vue.component('item-listing', {
    mixins: [AppListing]
});

