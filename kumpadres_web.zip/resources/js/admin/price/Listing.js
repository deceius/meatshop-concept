import AppListing from '../app-components/Listing/AppListing';

Vue.component('price-listing', {
    mixins: [AppListing]
});