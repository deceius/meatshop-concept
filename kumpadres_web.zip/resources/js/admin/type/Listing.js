import AppListing from '../app-components/Listing/AppListing';

Vue.component('type-listing', {
    mixins: [AppListing]
});